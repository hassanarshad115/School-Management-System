﻿using SchoolManagementSystem.Screens;
using SchoolManagementSystem.Screens.Branches;
using SchoolManagementSystem.Screens.EditProfile;
using SchoolManagementSystem.Screens.Login;
using SchoolManagementSystem.Screens.NewStudents;
using SchoolManagementSystem.Screens.Reports;
using SchoolManagementSystem.Screens.StartUp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SchoolManagementSystem
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new startForm()); //loginForm ki nameSpace ko enter kia ha
        }
    }
}
