﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SchoolManagementSystem.Screens.Templates
{
    public partial class TemplateForm : Form
    {
        public TemplateForm()
        {
            InitializeComponent();
        }

        public bool IsUpdatep { get; set; }
        /// <summary>
        /// phly isky sbsy phly form ko del kia fr ismy ak folder bnaya screens k name sy fr screens
        /// k ander template folder bnaya jsky ander TemplateForm bnaya jski kch properties set ki jsmy showInTaskBar ko false kia etc.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TemplateForm_Load(object sender, EventArgs e)
        {
            
        }
    }
}
