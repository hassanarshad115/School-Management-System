﻿using SchoolManagementSystem.Screens.Templates;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SchoolManagementSystem.Screens.Login
{
    public partial class SignUp : TemplateForm
    {
        public SignUp()
        {
            InitializeComponent();
        }

        private void savebutton1_Click(object sender, EventArgs e)
        {
            if (passwordtextBox2.Text == confirmpasswordtextBox4.Text)
            {
                saveKlye();
            }
            else
            {
                MessageBox.Show("Password is Not Match", "ERROR!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                passwordtextBox2.Clear();
                confirmpasswordtextBox4.Clear();
                passwordtextBox2.Focus();
                pswrdlabel6.ForeColor = Color.Red;
                cnfrmpswrdlabel3.ForeColor = Color.Red;
                pswrdlabel6.Enabled = true;
                cnfrmpswrdlabel3.Enabled = true;
            }

        }
        SqlConnection conn = new SqlConnection(ConfigurationClass.ConfigurationClassBnadiH());

        private void saveKlye()
        {
            if (isEmpty())
            {
                SqlCommand cmd = new SqlCommand("signup", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@u", usernametextBox1.Text.Trim());
                cmd.Parameters.AddWithValue("@p", passwordtextBox2.Text.Trim());
                cmd.Parameters.AddWithValue("@ic", maskedTextBox1.Text.Trim());
                //cmd.Parameters.Add("@ic", SqlDbType.BigInt).Value = maskedTextBox1.Text;

                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
                MessageBox.Show("Successfully SignUp", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Information);


                this.Close();
                loginForm l = new loginForm();
                l.Show();
            }
        }

        private bool isEmpty()
        {
            if (usernametextBox1.Text.Trim()==string.Empty)
            {
                MessageBox.Show("UserName is Required", "Error ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                usernametextBox1.Focus();
                return false;
            }
            if (passwordtextBox2.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Password is Required", "Error ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                passwordtextBox2.Focus();
                return false;
            }
            if (maskedTextBox1.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Id Card Number is Required", "Error ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                maskedTextBox1.Focus();
                return false;
            }
            
            return true;
        }
    }
}
