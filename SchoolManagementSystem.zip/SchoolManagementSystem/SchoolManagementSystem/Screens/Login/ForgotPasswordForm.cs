﻿using SchoolManagementSystem.Screens.Templates;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SchoolManagementSystem.Screens.Login
{
    public partial class ForgotPasswordForm : TemplateForm
    {
        public ForgotPasswordForm()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(ConfigurationClass.ConfigurationClassBnadiH());
        int count = 0;
        private void button1_Click(object sender, EventArgs e)
        {
            string query = "SELECT * FROM [User] WHERE IdCardNo='" + maskedTextBox1.Text + "'";
            SqlCommand cmd = new SqlCommand(query, conn);
            SqlDataReader rdr = null;

            conn.Open();
            rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                count = count + 1;
            }
            if (count > 0)
            {
                MessageBox.Show("Successfully Confirmed Password", "Confirmation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                newpswrdlabel2.Visible = true;
                groupBox1.Enabled = true;

            }

            else
            {
                MessageBox.Show(" Not Confirmed Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                maskedTextBox1.Text = string.Empty;
                maskedTextBox1.Focus();
            }
            conn.Close();

        }

        private void ForgotPasswordForm_Load(object sender, EventArgs e)
        {
            groupBox1.Enabled = false;
            newpswrdlabel2.Visible = false;
        }

        private void cbNewShow_CheckedChanged(object sender, EventArgs e)
        {
            if (cbNewShow.Checked)
            {
                txtNewPass.PasswordChar = default(char);
                txtRepAss.PasswordChar = default(char);

            }
            if (!cbNewShow.Checked)
            {
                txtRepAss.PasswordChar = Convert.ToChar("*");
                txtNewPass.PasswordChar = Convert.ToChar("*");

            }
        }
        private void TextBoxValidate()
        {
            if (txtNewPass.Text.Length == 0) return;
            else if (txtRepAss.Text.Length == 0) return;
            else ForgetValidation();
        }
        private void btnChangePass_Click(object sender, EventArgs e)
        {
            TextBoxValidate();
        }
        private void ForgetValidation()
        {

            string query = "UPDATE [User] SET Password='" + txtNewPass.Text + "' WHERE IdCardNo='" + maskedTextBox1.Text + "'";
            SqlCommand cmd = new SqlCommand(query, conn);
            try
            {
                conn.Open();
                int res = cmd.ExecuteNonQuery();
                if (res > 0)
                {
                    MessageBox.Show("Successfully Password Changed", "Password Recovery", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                    dashboardForm d = new dashboardForm();
                    d.Show();
                }
                else
                {
                    MessageBox.Show("Passwod Not Updated !", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            finally
            {
                conn.Close();
            }
        }
        private void txtRepAss_Leave(object sender, EventArgs e)
        {
            if (Validate(txtNewPass.Text, txtRepAss.Text) == false)
            {
                MessageBox.Show("Passwords Does not Match");
            }
        }
        private bool Validate(String pass, String Confirm)
        {
            return String.IsNullOrEmpty(pass) == false && pass == Confirm;
        }
    }
}