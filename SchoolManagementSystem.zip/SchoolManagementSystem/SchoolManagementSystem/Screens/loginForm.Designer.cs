﻿namespace SchoolManagementSystem.Screens
{
    partial class loginForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(loginForm));
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.label3 = new System.Windows.Forms.Label();
            this.captchalabel3 = new System.Windows.Forms.Label();
            this.showpasswordcheckBox1 = new System.Windows.Forms.CheckBox();
            this.capchatextBox1 = new System.Windows.Forms.TextBox();
            this.passwordtextBox2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.usernametextBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.loginbutton1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 10000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.linkLabel2.LinkColor = System.Drawing.Color.White;
            this.linkLabel2.Location = new System.Drawing.Point(376, 57);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(45, 13);
            this.linkLabel2.TabIndex = 78;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "Sign Up";
            this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel2_LinkClicked);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.linkLabel1.LinkColor = System.Drawing.Color.White;
            this.linkLabel1.Location = new System.Drawing.Point(335, 310);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(86, 13);
            this.linkLabel1.TabIndex = 78;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Forgot Password";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Elephant", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Location = new System.Drawing.Point(38, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(383, 38);
            this.label3.TabIndex = 77;
            this.label3.Text = "Login Page";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // captchalabel3
            // 
            this.captchalabel3.Font = new System.Drawing.Font("Elephant", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.captchalabel3.ForeColor = System.Drawing.Color.Red;
            this.captchalabel3.Location = new System.Drawing.Point(228, 165);
            this.captchalabel3.Name = "captchalabel3";
            this.captchalabel3.Size = new System.Drawing.Size(203, 32);
            this.captchalabel3.TabIndex = 6;
            this.captchalabel3.Text = "label3";
            this.captchalabel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // showpasswordcheckBox1
            // 
            this.showpasswordcheckBox1.AutoSize = true;
            this.showpasswordcheckBox1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.showpasswordcheckBox1.Location = new System.Drawing.Point(228, 234);
            this.showpasswordcheckBox1.Name = "showpasswordcheckBox1";
            this.showpasswordcheckBox1.Size = new System.Drawing.Size(102, 17);
            this.showpasswordcheckBox1.TabIndex = 5;
            this.showpasswordcheckBox1.Text = "&Show &Password";
            this.showpasswordcheckBox1.UseVisualStyleBackColor = true;
            this.showpasswordcheckBox1.CheckedChanged += new System.EventHandler(this.showpasswordcheckBox1_CheckedChanged);
            // 
            // capchatextBox1
            // 
            this.capchatextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.capchatextBox1.Location = new System.Drawing.Point(336, 200);
            this.capchatextBox1.Multiline = true;
            this.capchatextBox1.Name = "capchatextBox1";
            this.capchatextBox1.Size = new System.Drawing.Size(85, 26);
            this.capchatextBox1.TabIndex = 2;
            this.capchatextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // passwordtextBox2
            // 
            this.passwordtextBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passwordtextBox2.Location = new System.Drawing.Point(227, 136);
            this.passwordtextBox2.Multiline = true;
            this.passwordtextBox2.Name = "passwordtextBox2";
            this.passwordtextBox2.PasswordChar = '*';
            this.passwordtextBox2.Size = new System.Drawing.Size(194, 26);
            this.passwordtextBox2.TabIndex = 1;
            this.passwordtextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(225, 206);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(101, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "&Enter Captcha Here";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(225, 117);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "&Password";
            // 
            // usernametextBox1
            // 
            this.usernametextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usernametextBox1.Location = new System.Drawing.Point(227, 84);
            this.usernametextBox1.Multiline = true;
            this.usernametextBox1.Name = "usernametextBox1";
            this.usernametextBox1.Size = new System.Drawing.Size(194, 26);
            this.usernametextBox1.TabIndex = 0;
            this.usernametextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(225, 65);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "&UserName";
            // 
            // button2
            // 
            this.button2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button2.BackgroundImage")));
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button2.Location = new System.Drawing.Point(375, 258);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(46, 40);
            this.button2.TabIndex = 4;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // loginbutton1
            // 
            this.loginbutton1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("loginbutton1.BackgroundImage")));
            this.loginbutton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.loginbutton1.Location = new System.Drawing.Point(228, 258);
            this.loginbutton1.Name = "loginbutton1";
            this.loginbutton1.Size = new System.Drawing.Size(46, 40);
            this.loginbutton1.TabIndex = 3;
            this.loginbutton1.UseVisualStyleBackColor = true;
            this.loginbutton1.Click += new System.EventHandler(this.loginbutton1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SchoolManagementSystem.Properties.Resources.Apps_preferences_system_login_icon__1_;
            this.pictureBox1.Location = new System.Drawing.Point(12, 65);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(183, 192);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // loginForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSlateGray;
            this.ClientSize = new System.Drawing.Size(440, 335);
            this.Controls.Add(this.linkLabel2);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.captchalabel3);
            this.Controls.Add(this.showpasswordcheckBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.loginbutton1);
            this.Controls.Add(this.capchatextBox1);
            this.Controls.Add(this.passwordtextBox2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.usernametextBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "loginForm";
            this.ShowInTaskbar = true;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.loginForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox usernametextBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox passwordtextBox2;
        private System.Windows.Forms.Button loginbutton1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.CheckBox showpasswordcheckBox1;
        private System.Windows.Forms.TextBox capchatextBox1;
        private System.Windows.Forms.Label captchalabel3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.LinkLabel linkLabel2;
    }
}