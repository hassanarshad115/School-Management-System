﻿using SchoolManagementSystem.Screens.Branches;
using SchoolManagementSystem.Screens.EditProfile;
using SchoolManagementSystem.Screens.ManageUsers;
using SchoolManagementSystem.Screens.NewStudents;
using SchoolManagementSystem.Screens.Reports;
using SchoolManagementSystem.Screens.Templates;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SchoolManagementSystem.Screens
{
    public partial class dashboardForm : TemplateForm
    {
        public dashboardForm()
        {
            InitializeComponent();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void schoolManagementSystemToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CRCrystalReportForm1 report1 = new CRCrystalReportForm1();
            report1.ShowDialog();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            ManageBranchesForm mbf = new ManageBranchesForm();
            mbf.ShowDialog();
        }

    
       

        private void toolStripButton7_Click(object sender, EventArgs e)
        {
            helpAndSupportForm hs = new helpAndSupportForm();
            hs.ShowDialog();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            ManageStudentsForm obj = new ManageStudentsForm();
            obj.ShowDialog();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            ManageProfileForm obj = new ManageProfileForm();
            obj.ShowDialog();
        }

        private void schoolManagementSystemToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Application is Created by Hassan Malik \nFrom BahawalNagar ", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private void allStudentsReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CRStudentInfoForm obj = new CRStudentInfoForm();
            obj.ShowDialog();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            ManageUsersForm muf = new ManageUsersForm(); ;
            muf.ShowDialog();
        }

        private void dashboardForm_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = GetDataForComboBox("select [EnrollmentNo],[AdmissionNo],[Name],[FatherName],[DateOfAdmission],[City],[District],[BranchName]from [StdInfoTbl]");
            dataGridView1.Refresh();
        }
        private DataTable GetDataForComboBox(string sp)
        {
            DataTable dt = new DataTable();

            SqlConnection conn = new SqlConnection(ConfigurationClass.ConfigurationClassBnadiH());
            SqlDataAdapter adapter = new SqlDataAdapter(sp, conn);
            adapter.Fill(dt);

            return dt;
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            
        }
    }
}
