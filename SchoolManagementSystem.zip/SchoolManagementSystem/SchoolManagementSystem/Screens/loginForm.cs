﻿using SchoolManagementSystem.Screens.Login;
using SchoolManagementSystem.Screens.Templates;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SchoolManagementSystem.Screens
{
    public partial class loginForm : TemplateForm //phly normal form likha hoa ta mgr mujhy template form ki functionltes chaia ti so us sy isko drieved kra ho
    {
        /// <summary>
        /// isko templateForm sy derieved kia ha but iski kch propertes bad ma change ki h jsy 
        /// showInTaskBar ko true wgera.
        /// </summary>
        public loginForm()
        {
            InitializeComponent();
            LoadChaptcha();
        }
        int a = 0;
        private void LoadChaptcha()
        {
            Random r = new Random();
            a = r.Next(100, 10000);
            captchalabel3.Text = a.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void showpasswordcheckBox1_CheckedChanged(object sender, EventArgs e)
        {
            showPasswordMethod();
        }

        private void showPasswordMethod()
        {
            if (showpasswordcheckBox1.Checked)
            {
                passwordtextBox2.PasswordChar = default(char);
            }
            if (!showpasswordcheckBox1.Checked)
            {
                passwordtextBox2.PasswordChar = Convert.ToChar("*");
            }
        }

        private void loginbutton1_Click(object sender, EventArgs e)
        {
            if (isFormValidate())
            {
                bool isCorrectUsername, isCorrectPassword;
                getLoginMethod(out isCorrectUsername, out isCorrectPassword);

                if(isCorrectUsername && isCorrectPassword)
                {
                    if (captchalabel3.Text == capchatextBox1.Text)
                    {
                        this.Hide();
                        dashboardForm obj = new dashboardForm();
                        obj.Show();
                    }
                    else
                    {
                        MessageBox.Show("Captcha is Not Correct", "ERROR!!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        capchatextBox1.Clear();
                        capchatextBox1.Focus();
                    }
                }
                else
                {
                    if (!isCorrectUsername)
                    {
                        MessageBox.Show("User Name is Not Correct", "ERROR!!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        usernametextBox1.Clear();
                        passwordtextBox2.Clear();
                        usernametextBox1.Focus();
                    }
                    else
                    {
                        MessageBox.Show("Password is Not Correct", "ERROR!!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        passwordtextBox2.Clear();
                        passwordtextBox2.Focus();
                    }
                }
               
            }
        }

        private void getLoginMethod(out bool isCorrectUsername, out bool isCorrectPassword)
        {
            //string connectionstring = ConfigurationManager.ConnectionStrings["db"].ConnectionString;

            SqlConnection conn = new SqlConnection(ConfigurationClass.ConfigurationClassBnadiH());//configuratioin Calss ko Call kia ha yaha
            SqlCommand cmd = new SqlCommand("loginKLye", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            conn.Open();
            //ye login k lye ha k parameters ksy dny hain
            cmd.Parameters.Add("@isu", SqlDbType.Bit).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("@isp", SqlDbType.Bit).Direction = ParameterDirection.Output;
            //ye normal parameters dny ka treeka ha
            cmd.Parameters.AddWithValue("@u", usernametextBox1.Text.Trim());
            cmd.Parameters.AddWithValue("@p", passwordtextBox2.Text.Trim());

            //ye insert/update/delete k lye method ha
            cmd.ExecuteNonQuery();
            //use veriables of method getLoginMethod
            isCorrectUsername =(bool) cmd.Parameters["@isu"].Value;
            isCorrectPassword = (bool)cmd.Parameters["@isp"].Value;

        }

        private bool isFormValidate()
        {
            if(usernametextBox1.Text.Trim()== string.Empty)
            {
                MessageBox.Show("User Name TextBox is Empty","ERROR!!!",MessageBoxButtons.OK,MessageBoxIcon.Error);
                usernametextBox1.Clear();
                usernametextBox1.Focus();
                return false;
            }
            if (passwordtextBox2.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Password TextBox is Empty", "ERROR!!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                passwordtextBox2.Clear();
                passwordtextBox2.Focus();
                return false;
            }
            return true;
        }

        private void loginForm_Load(object sender, EventArgs e)
        {
           

        }

        private void button1_Click(object sender, EventArgs e)
        {
            LoadChaptcha();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            LoadChaptcha();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            SignUp su = new SignUp();
            su.ShowDialog();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            ForgotPasswordForm f = new ForgotPasswordForm();
            f.Show();
        }
    }
}
