﻿using SchoolManagementSystem.Screens.Templates;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SchoolManagementSystem.Screens.EditProfile
{
    public partial class ManageProfileForm : TemplateForm
    {
        public ManageProfileForm()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(ConfigurationClass.ConfigurationClassBnadiH());


        private void ManageProfileForm_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = GitData();
        }

        private DataTable GitData()
        {
            DataTable dt = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter("select * from [dbo].[User]", conn);
            adapter.Fill(dt);
            return dt;
        }

     

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            

            int index = dataGridView1.Rows.GetFirstRow(DataGridViewElementStates.Selected);
            string row = dataGridView1.Rows[index].Cells[0].Value.ToString();
            string row1 = dataGridView1.Rows[index].Cells[1].Value.ToString();
            string row2 = dataGridView1.Rows[index].Cells[2].Value.ToString();

            AddNewRecordForm obj = new AddNewRecordForm();
            obj.usernameP = row.ToString();
            obj.passwordP = row1.ToString();
            obj.createdByP = row2.ToString();

            obj.updatebuttoninaddnewrecord = true;
            obj.Show();
            //this.Hide();
            
        }

        private void addNewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddNewRecordForm obj = new AddNewRecordForm();
            obj.savebuttoninaddnewrecord = true;
            obj.ShowDialog();
        }
    }
}
