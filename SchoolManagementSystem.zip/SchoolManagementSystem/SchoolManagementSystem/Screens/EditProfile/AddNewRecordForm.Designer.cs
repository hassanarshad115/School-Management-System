﻿namespace SchoolManagementSystem.Screens.EditProfile
{
    partial class AddNewRecordForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRecordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.updateRecordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.usernametextBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.passwordtextBox2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.confirmpasswordtextBox4 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.createdbycomboBox1 = new System.Windows.Forms.ComboBox();
            this.updatebutton1 = new System.Windows.Forms.Button();
            this.savebutton1 = new System.Windows.Forms.Button();
            this.cnfrmpswrdlabel3 = new System.Windows.Forms.Label();
            this.pswrdlabel6 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.closeToolStripMenuItem,
            this.toolStripMenuItem1,
            this.saveRecordToolStripMenuItem,
            this.toolStripMenuItem2,
            this.updateRecordToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(347, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.closeToolStripMenuItem.Text = "&Close";
            this.closeToolStripMenuItem.Click += new System.EventHandler(this.closeToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(22, 20);
            this.toolStripMenuItem1.Text = "|";
            // 
            // saveRecordToolStripMenuItem
            // 
            this.saveRecordToolStripMenuItem.Name = "saveRecordToolStripMenuItem";
            this.saveRecordToolStripMenuItem.Size = new System.Drawing.Size(22, 20);
            this.saveRecordToolStripMenuItem.Text = " ";
            this.saveRecordToolStripMenuItem.Click += new System.EventHandler(this.saveRecordToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(22, 20);
            this.toolStripMenuItem2.Text = " ";
            // 
            // updateRecordToolStripMenuItem
            // 
            this.updateRecordToolStripMenuItem.Name = "updateRecordToolStripMenuItem";
            this.updateRecordToolStripMenuItem.Size = new System.Drawing.Size(22, 20);
            this.updateRecordToolStripMenuItem.Text = " ";
            this.updateRecordToolStripMenuItem.Click += new System.EventHandler(this.updateRecordToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(11, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "UserName";
            // 
            // usernametextBox1
            // 
            this.usernametextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usernametextBox1.Location = new System.Drawing.Point(134, 47);
            this.usernametextBox1.Name = "usernametextBox1";
            this.usernametextBox1.Size = new System.Drawing.Size(152, 23);
            this.usernametextBox1.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(11, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Password";
            // 
            // passwordtextBox2
            // 
            this.passwordtextBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passwordtextBox2.Location = new System.Drawing.Point(134, 76);
            this.passwordtextBox2.Name = "passwordtextBox2";
            this.passwordtextBox2.Size = new System.Drawing.Size(152, 23);
            this.passwordtextBox2.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label4.Location = new System.Drawing.Point(11, 108);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(121, 17);
            this.label4.TabIndex = 1;
            this.label4.Text = "Confirm Password";
            // 
            // confirmpasswordtextBox4
            // 
            this.confirmpasswordtextBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.confirmpasswordtextBox4.Location = new System.Drawing.Point(134, 105);
            this.confirmpasswordtextBox4.Name = "confirmpasswordtextBox4";
            this.confirmpasswordtextBox4.Size = new System.Drawing.Size(152, 23);
            this.confirmpasswordtextBox4.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label5.Location = new System.Drawing.Point(11, 137);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 17);
            this.label5.TabIndex = 1;
            this.label5.Text = "Created By";
            // 
            // createdbycomboBox1
            // 
            this.createdbycomboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.createdbycomboBox1.FormattingEnabled = true;
            this.createdbycomboBox1.Items.AddRange(new object[] {
            ""});
            this.createdbycomboBox1.Location = new System.Drawing.Point(134, 137);
            this.createdbycomboBox1.Name = "createdbycomboBox1";
            this.createdbycomboBox1.Size = new System.Drawing.Size(152, 21);
            this.createdbycomboBox1.TabIndex = 4;
            // 
            // updatebutton1
            // 
            this.updatebutton1.Enabled = false;
            this.updatebutton1.Location = new System.Drawing.Point(210, 165);
            this.updatebutton1.Name = "updatebutton1";
            this.updatebutton1.Size = new System.Drawing.Size(75, 23);
            this.updatebutton1.TabIndex = 5;
            this.updatebutton1.Text = "&Update ";
            this.updatebutton1.UseVisualStyleBackColor = true;
            this.updatebutton1.Click += new System.EventHandler(this.updatebutton1_Click);
            // 
            // savebutton1
            // 
            this.savebutton1.Location = new System.Drawing.Point(134, 164);
            this.savebutton1.Name = "savebutton1";
            this.savebutton1.Size = new System.Drawing.Size(75, 23);
            this.savebutton1.TabIndex = 6;
            this.savebutton1.Text = "&Save";
            this.savebutton1.UseVisualStyleBackColor = true;
            this.savebutton1.Click += new System.EventHandler(this.savebutton1_Click);
            // 
            // cnfrmpswrdlabel3
            // 
            this.cnfrmpswrdlabel3.AutoSize = true;
            this.cnfrmpswrdlabel3.Font = new System.Drawing.Font("Elephant", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cnfrmpswrdlabel3.ForeColor = System.Drawing.Color.CadetBlue;
            this.cnfrmpswrdlabel3.Location = new System.Drawing.Point(289, 108);
            this.cnfrmpswrdlabel3.Name = "cnfrmpswrdlabel3";
            this.cnfrmpswrdlabel3.Size = new System.Drawing.Size(16, 18);
            this.cnfrmpswrdlabel3.TabIndex = 7;
            this.cnfrmpswrdlabel3.Text = "*";
            this.toolTip1.SetToolTip(this.cnfrmpswrdlabel3, "Password is Not Match");
            // 
            // pswrdlabel6
            // 
            this.pswrdlabel6.AutoSize = true;
            this.pswrdlabel6.Font = new System.Drawing.Font("Elephant", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pswrdlabel6.ForeColor = System.Drawing.Color.CadetBlue;
            this.pswrdlabel6.Location = new System.Drawing.Point(289, 81);
            this.pswrdlabel6.Name = "pswrdlabel6";
            this.pswrdlabel6.Size = new System.Drawing.Size(16, 18);
            this.pswrdlabel6.TabIndex = 7;
            this.pswrdlabel6.Text = "*";
            this.toolTip1.SetToolTip(this.pswrdlabel6, "Password is Not Match");
            // 
            // AddNewRecordForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(347, 203);
            this.Controls.Add(this.pswrdlabel6);
            this.Controls.Add(this.cnfrmpswrdlabel3);
            this.Controls.Add(this.savebutton1);
            this.Controls.Add(this.updatebutton1);
            this.Controls.Add(this.createdbycomboBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.confirmpasswordtextBox4);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.passwordtextBox2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.usernametextBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "AddNewRecordForm";
            this.Text = "AddNewRecordForm";
            this.Load += new System.EventHandler(this.AddNewRecordForm_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox usernametextBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox passwordtextBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox confirmpasswordtextBox4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox createdbycomboBox1;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem saveRecordToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem updateRecordToolStripMenuItem;
        private System.Windows.Forms.Button updatebutton1;
        private System.Windows.Forms.Button savebutton1;
        private System.Windows.Forms.Label cnfrmpswrdlabel3;
        private System.Windows.Forms.Label pswrdlabel6;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}