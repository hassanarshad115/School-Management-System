﻿using SchoolManagementSystem.Screens.Templates;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SchoolManagementSystem.Screens.EditProfile
{
    public partial class AddNewRecordForm : TemplateForm
    {
        public AddNewRecordForm()
        {
            InitializeComponent();
        }

        public string usernameP { get; set; }
        public string passwordP { get; set; }
        public string createdByP { get; set; }
        public bool updatebuttoninaddnewrecord { get; set; }
        public bool savebuttoninaddnewrecord { get; set; }
        SqlConnection conn = new SqlConnection(ConfigurationClass.ConfigurationClassBnadiH());
        DataSet ds = new DataSet();
        SqlCommand cm;

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void updatebutton1_Click(object sender, EventArgs e)
        {

            if (passwordtextBox2.Text == confirmpasswordtextBox4.Text)
            {
                UpdateKlye();
            }
            else
            {
                MessageBox.Show("Password is Not Match", "ERROR!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                passwordtextBox2.Clear();
                confirmpasswordtextBox4.Clear();
                passwordtextBox2.Focus();
                pswrdlabel6.ForeColor = Color.Red;
                cnfrmpswrdlabel3.ForeColor = Color.Red;
                pswrdlabel6.Enabled = true;
                cnfrmpswrdlabel3.Enabled = true;
            }
        }

        private void savebutton1_Click(object sender, EventArgs e)
        {
            if (passwordtextBox2.Text == confirmpasswordtextBox4.Text)
            {
                saveKlye();
            }
            else
            {
                MessageBox.Show("Password is Not Match", "ERROR!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                passwordtextBox2.Clear();
                confirmpasswordtextBox4.Clear();
                passwordtextBox2.Focus();
                pswrdlabel6.ForeColor = Color.Red;
                cnfrmpswrdlabel3.ForeColor = Color.Red;
                pswrdlabel6.Enabled = true;
                cnfrmpswrdlabel3.Enabled = true;
            }

            //UpdateKlye();
        }
        private void saveRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }


        private void saveKlye()
        {
            cm = new SqlCommand("select * from [User] where Username='" + usernametextBox1.Text.Trim() + "'", conn);
            SqlDataAdapter adapter = new SqlDataAdapter(cm);
            adapter.Fill(ds);
            int i = ds.Tables[0].Rows.Count;
            if (i > 0)
            {
                MessageBox.Show("User Name " + usernametextBox1.Text.Trim() + " is Already Exist", "ERROR!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();

            }
            else
            {
                if (isEmpty())
                {
                    SqlCommand cmd = new SqlCommand("insertIntoUser", conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@username", usernametextBox1.Text.Trim());
                    cmd.Parameters.AddWithValue("@password", passwordtextBox2.Text.Trim());
                    cmd.Parameters.AddWithValue("@createdBy", createdbycomboBox1.Text);
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    MessageBox.Show("Successfully SAVE Record", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Information);


                    this.Close();
                    ManageProfileForm obj = new ManageProfileForm();
                    obj.Show();
                }
            }
        }

        private bool isEmpty()
        {
            if (usernametextBox1.Text.Trim() == string.Empty)
            {
                MessageBox.Show("UserName is Required","Error ",MessageBoxButtons.OK,MessageBoxIcon.Error);
                usernametextBox1.Focus();
                return false;
            }
            if (passwordtextBox2.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Password is Required", "Error ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                passwordtextBox2.Focus();
                return false;
            }
            if (createdbycomboBox1.SelectedIndex==-1)
            {
                MessageBox.Show("CreatedBy is Required", "Error ", MessageBoxButtons.OK, MessageBoxIcon.Error);
               
                return false;
            }
            return true;
        }

        private void UpdateKlye()
        {
            if (isEmpty())
            {
                DialogResult result = MessageBox.Show("Do You Want To Update Record By UserName ??", "WARNING", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                if (result == DialogResult.OK)//ok krna h 
                {
                    SqlCommand cmd = new SqlCommand("UpdateIntoUsertbl", conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@username", usernametextBox1.Text.Trim());
                    cmd.Parameters.AddWithValue("@password", passwordtextBox2.Text.Trim());
                    cmd.Parameters.AddWithValue("@createdBy", createdbycomboBox1.Text);
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    MessageBox.Show("Successfully Update Record", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Information);


                    this.Close();
                    ManageProfileForm obj = new ManageProfileForm();
                    obj.Show();

                }
            }
        }
        private void AddNewRecordForm_Load(object sender, EventArgs e)
        {
            createdbycomboBox1.DataSource = GetData("select Descriptioin from Role");
            createdbycomboBox1.DisplayMember = "Descriptioin";
            //mene combobox ki properties ma ja k collection ma ak enter mara ha bs
            //createdbycomboBox1.SelectedIndex = -1;

            usernametextBox1.Text = usernameP;
            passwordtextBox2.Text = passwordP;
            createdbycomboBox1.Text = createdByP;
            updatebutton1.Enabled = updatebuttoninaddnewrecord;
            savebutton1.Enabled = savebuttoninaddnewrecord;
            pswrdlabel6.Enabled = false;
            cnfrmpswrdlabel3.Enabled = false;


        }
        private DataTable GetData(string sp)
        {
            DataTable dt = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(sp, conn);
            adapter.Fill(dt);
            return dt;
        }
        private void updateRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }


    }
}
