﻿using SchoolManagementSystem.Properties;
using SchoolManagementSystem.Screens.Templates;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SchoolManagementSystem.Screens.Branches
{
    public partial class branchInfoForm : TemplateForm
    {
        public branchInfoForm()
        {
            InitializeComponent();
        }

        //public int BranchInfoP { get; set; }


        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void branchNametextBox1_TextChanged(object sender, EventArgs e)
        {
            branchNamelabel1.Text = branchNametextBox1.Text;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "Select Logo";
            ofd.Filter = "Select Logo(*.PNG;*.JPG;*.BMP;*.GIF)|*.png;*.jpg;*.bmp;*.gif";

            if (ofd.ShowDialog() == DialogResult.OK)//ok krna ha
            {
                //nchy wali lina ko showDialgo() k bad he likhni h hmesha wrna isny ni chlna  
                pictureBox1.Image = new Bitmap(ofd.FileName);
            }

        }
        public bool delbuttonp { get; set; }//property 
        public int StudentIDp { get; set; }
        public bool isUpdatep { get; set; }
        private void branchInfoForm_Load(object sender, EventArgs e)
        {

            savebutton2.Enabled = delbuttonp;
            //IN DONO COMBOBOX KA CODE isUpdatep sy phly likhna ha lazmi
            //NOTE
            cityNamecomboBox1.DataSource = GetDataForComboBox("select City from  CityAndDistric");
            cityNamecomboBox1.DisplayMember = "City";
            cityNamecomboBox1.SelectedIndex = -1;

            districtNamecomboBox2.DataSource = GetDataForComboBox("select District from CityAndDistric");
            districtNamecomboBox2.DisplayMember = "District";
            districtNamecomboBox2.SelectedIndex = -1;

            if (this.isUpdatep)
            {

                DataTable dtStudentInfo = StdInfoMethod(this.StudentIDp);//property/veriable ko this k sath dala ha jo uper bnae ti

                DataRow row = dtStudentInfo.Rows[0];

                branchNametextBox1.Text     = row["BranchName"].ToString();
                emailAddresstextBox2.Text   = row["Email"].ToString();
                telephonetextBox3.Text = row["Telephone"].ToString();
                websiteAddresstextBox4.Text = row["Website"].ToString();
                addressLinetextBox5.Text = row["AddressLine"].ToString();

                cityNamecomboBox1.Text = row["City"].ToString();
                districtNamecomboBox2.Text = row["District"].ToString();

                postCodetextBox8.Text = row["PostCode"].ToString();
                pictureBox1.Image = (row["BranchImage"] is DBNull) ? Resources.no_image_available : GetPoto((byte[])row["BranchImage"]);


            }

        }
        private DataTable StdInfoMethod(int studentP)
        {
            DataTable obj = new DataTable();

            SqlConnection con = new SqlConnection(ConfigurationClass.ConfigurationClassBnadiH());

            SqlCommand cmd = new SqlCommand("dekhna", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@stdID", studentP);

            con.Open();
            SqlDataReader r = cmd.ExecuteReader();
            obj.Load(r);

            con.Close();

            //SqlDataAdapter ad = new SqlDataAdapter("dekhna", con);
            //ad.Fill(obj);
            return obj;
        }

        //phly byte array ko memorystream ma change kia ta ab
        //memorystream ko byte array ma change krygy
        private Image GetPoto(byte[] photo)//v ki jga photo likhdia
        {
            System.IO.MemoryStream ms = new System.IO.MemoryStream(photo);

            return Image.FromStream(ms);
        }


        private void savebutton2_Click(object sender, EventArgs e)
        {
            if (this.isUpdatep)
            {
                UpdateKlyeMethod(); //new property bna kr usmy ye code kia ha
            }
            else
            {
                SavekAnderWalaMethod();
            }
        }

        SqlCommand cm;
        DataSet ds = new DataSet();

        private void SavekAnderWalaMethod()
        {
            if (isEmpty())
            {
                SqlConnection conn = new SqlConnection(ConfigurationClass.ConfigurationClassBnadiH());
                cm = new SqlCommand("select * from Branches where BranchName='" + branchNametextBox1.Text.Trim() + "'", conn);
                SqlDataAdapter ad = new SqlDataAdapter(cm);
                ad.Fill(ds);
                int i = ds.Tables[0].Rows.Count;
                if (i > 0)
                {
                    MessageBox.Show("Branche Name " + branchNametextBox1.Text + " is Already Exist", "ERROR!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.Close();

                }
                else
                {
                    SqlCommand cmd = new SqlCommand("i", conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open();

                    cmd.Parameters.AddWithValue("@branchname", branchNametextBox1.Text.Trim());
                    cmd.Parameters.AddWithValue("@email", emailAddresstextBox2.Text.Trim());
                    cmd.Parameters.AddWithValue("@telephone", telephonetextBox3.Text.Trim());
                    cmd.Parameters.AddWithValue("@web", websiteAddresstextBox4.Text.Trim());
                    cmd.Parameters.AddWithValue("@bimage", SavePhoto());

                    cmd.Parameters.AddWithValue("@adresline", addressLinetextBox5.Text.Trim());
                    cmd.Parameters.AddWithValue("@city", cityNamecomboBox1.Text);
                    cmd.Parameters.AddWithValue("@district", districtNamecomboBox2.Text.Trim());
                    cmd.Parameters.AddWithValue("@postalcode", postCodetextBox8.Text.Trim());

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Successfully SAVE Record", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    conn.Close();


                }
                this.Hide();
                ManageBranchesForm mbf = new ManageBranchesForm();

                mbf.Show();
            }
        }

        private byte[] SavePhoto()//byte[] array lena ha
        {
            System.IO.MemoryStream ms = new MemoryStream();//memory stream array ki trah ha IO sy enter krni ha
            //image save krny k lye
            pictureBox1.Image.Save(ms, pictureBox1.Image.RawFormat);//ks format m save krni ha
            return ms.GetBuffer(); // lazmi
        }

        private void UpdateKlyeMethod()
        {

            if (isEmpty())
            {
                DialogResult result = MessageBox.Show("Do You Want To Update Records ???", "WARNING", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)//yes hoga
                {

                    SqlConnection conn = new SqlConnection(ConfigurationClass.ConfigurationClassBnadiH());

                    SqlCommand cmd = new SqlCommand("up", conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open();

                    cmd.Parameters.AddWithValue("@branchname", branchNametextBox1.Text.Trim());
                    cmd.Parameters.AddWithValue("@email", emailAddresstextBox2.Text.Trim());
                    cmd.Parameters.AddWithValue("@telephone", telephonetextBox3.Text.Trim());
                    cmd.Parameters.AddWithValue("@web", websiteAddresstextBox4.Text.Trim());
                    cmd.Parameters.AddWithValue("@bimage", SavePhoto());

                    cmd.Parameters.AddWithValue("@adresline", addressLinetextBox5.Text.Trim());
                    cmd.Parameters.AddWithValue("@city", cityNamecomboBox1.Text);
                    cmd.Parameters.AddWithValue("@district", districtNamecomboBox2.Text.Trim());
                    cmd.Parameters.AddWithValue("@postalcode", postCodetextBox8.Text.Trim());

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Successfully UPDATE Record", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    this.Hide();


                    ManageBranchesForm mbf = new ManageBranchesForm();
                    mbf.Show();
                }
            }
        }

        private DataTable GetDataForComboBox(string sp)
        {
            DataTable dt = new DataTable();

            SqlConnection conn = new SqlConnection(ConfigurationClass.ConfigurationClassBnadiH());
            SqlDataAdapter adapter = new SqlDataAdapter(sp, conn);
            adapter.Fill(dt);

            return dt;
        }



        private bool isEmpty()
        {
            if (branchNametextBox1.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Branch Name is Required", "ERROR!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                branchNametextBox1.Focus();
                return false;
            }
            if (emailAddresstextBox2.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Email is Required", "ERROR!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                emailAddresstextBox2.Focus();
                return false;
            }
            if (telephonetextBox3.Text.Trim() == string.Empty)
            {
                MessageBox.Show("TelePhone is Required", "ERROR!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                telephonetextBox3.Focus();
                return false;
            }
            if (websiteAddresstextBox4.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Website Address is Required", "ERROR!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                websiteAddresstextBox4.Focus();
                return false;
            }
            if (cityNamecomboBox1.SelectedIndex == -1)
            {
                MessageBox.Show("City Name is Required", "ERROR!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            if (districtNamecomboBox2.SelectedIndex == -1)
            {
                MessageBox.Show("Destrict Name is Required", "ERROR!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            if (postCodetextBox8.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Postal Code is Required", "ERROR!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                postCodetextBox8.Focus();
                return false;
            }


            return true;
        }




        private void telephonetextBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            EnterOnlyNumber(e);
        }

        private static void EnterOnlyNumber(KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (char.IsLetter(ch))
            {
                MessageBox.Show("Please Enter Only Number", "ERROR!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                e.Handled = true;
            }
        }

        private void postCodetextBox8_KeyPress(object sender, KeyPressEventArgs e)
        {
            EnterOnlyNumber(e);

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void deletebutton2_Click(object sender, EventArgs e)
        {
            if (isEmpty())
            {
                DialogResult result = MessageBox.Show("Do You Want To Delete Records ???\nIf You Delete Record,You Cannot Retrieve This Record.", "WARNING", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)
                {
                    SqlConnection conn = new SqlConnection(ConfigurationClass.ConfigurationClassBnadiH());

                    SqlCommand cmd = new SqlCommand("del", conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open();

                    cmd.Parameters.AddWithValue("@branchname", branchNametextBox1.Text.Trim());
                    cmd.Parameters.AddWithValue("@email", emailAddresstextBox2.Text.Trim());
                    cmd.Parameters.AddWithValue("@telephone", telephonetextBox3.Text.Trim());
                    cmd.Parameters.AddWithValue("@web", websiteAddresstextBox4.Text.Trim());
                    //cmd.Parameters.AddWithValue("@bimage", SavePhoto());

                    cmd.Parameters.AddWithValue("@adresline", addressLinetextBox5.Text.Trim());
                    cmd.Parameters.AddWithValue("@c", cityNamecomboBox1.Text);
                    cmd.Parameters.AddWithValue("@d", districtNamecomboBox2.Text.Trim());
                    cmd.Parameters.AddWithValue("@postalcode", postCodetextBox8.Text.Trim());

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Successfully Delete Record", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    conn.Close();
                    this.Hide();


                    ManageBranchesForm mbf = new ManageBranchesForm();

                    mbf.Show();
                }
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }


    }
}