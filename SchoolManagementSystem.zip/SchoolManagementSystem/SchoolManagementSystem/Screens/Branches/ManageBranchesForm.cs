﻿using SchoolManagementSystem.Screens.Templates;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SchoolManagementSystem.Screens.Branches
{
    public partial class ManageBranchesForm : TemplateForm
    {
        public ManageBranchesForm()
        {
            InitializeComponent();
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void addBranchToolStripMenuItem_Click(object sender, EventArgs e)
        {

            ShowStudentInfo(0, false);


            manageBranchesdataGridView1.DataSource = getDataMethod("getAllBranches");

        }
        private void ShowStudentInfo(int studentIDv, bool isUpdate)
        {

            branchInfoForm obj = new branchInfoForm();
            obj.delbuttonp = true;
            obj.StudentIDp = studentIDv;
            obj.isUpdatep = isUpdate;
            obj.ShowDialog();
        }
        private void manageBranchesdataGridView1_DoubleClick(object sender, EventArgs e)
        {

            int rowUpdate = manageBranchesdataGridView1.Rows.GetFirstRow(DataGridViewElementStates.Selected);
            int studentID = Convert.ToInt16(manageBranchesdataGridView1.Rows[rowUpdate].Cells[0].Value);//convert krny ka treeka b dekh ly

            ShowStudentInfo(studentID, true);//isko insert new student ma b add kry


            manageBranchesdataGridView1.DataSource = getDataMethod("getAllBranches");


        }

        private void ManageBranchesForm_Load(object sender, EventArgs e)
        {
            manageBranchesdataGridView1.DataSource = getDataMethod("getAllBranches");
            manageBranchesdataGridView1.Columns[0].Visible = false;


        }
        //data gridview ma data show krny k lye
        private DataTable getDataMethod(string sp)
        {
            DataTable dt = new DataTable();

            SqlConnection conn = new SqlConnection(ConfigurationClass.ConfigurationClassBnadiH());
            SqlDataAdapter adapter = new SqlDataAdapter(sp, conn);
            adapter.Fill(dt);

            return dt;
        }

        

       

        private void addCityAndDistrictToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CityandDistrictForm obj = new CityandDistrictForm();
            obj.ShowDialog();
        }

        private void addNewBranchesToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
