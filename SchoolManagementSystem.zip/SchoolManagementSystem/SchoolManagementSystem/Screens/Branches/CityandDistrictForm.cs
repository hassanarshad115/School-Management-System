﻿using SchoolManagementSystem.Screens.Templates;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SchoolManagementSystem.Screens.Branches
{
    public partial class CityandDistrictForm : TemplateForm
    {
        public CityandDistrictForm()
        {
            InitializeComponent();
        }
        SqlCommand cmd;
        DataSet ds = new DataSet();
        SqlConnection conn = new SqlConnection(ConfigurationClass.ConfigurationClassBnadiH());

        private void button3_Click(object sender, EventArgs e)
        {
            if (isEmpty())
            {
                cmd = new SqlCommand("select * from CityAndDistric where City='" + CITYNAMEtextBox1.Text.Trim()+"'", conn);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                adapter.Fill(ds);
                int i = ds.Tables[0].Rows.Count;
                if (i > 0)
                {
                    MessageBox.Show("City Name "+CITYNAMEtextBox1.Text+" is already exists", "ERROR!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.Close();
                }
                else
                {//forCityAndDistrictUpdatetData
                    cmd = new SqlCommand("forCityAndDistrictInsertData", conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open();

                    cmd.Parameters.AddWithValue("@c", CITYNAMEtextBox1.Text.Trim());
                    cmd.Parameters.AddWithValue("@d", DISTRICTNAMEtextBox2.Text.Trim());
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Record Successfully Saved","INFORMATION",MessageBoxButtons.OK,MessageBoxIcon.Information);
                    dataGridView1.DataSource = Getdata();
                    conn.Close();
                }
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {

            cmd = new SqlCommand("forCityAndDistrictUpdatetData", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            conn.Open();

            cmd.Parameters.AddWithValue("@c", CITYNAMEtextBox1.Text.Trim());
            cmd.Parameters.AddWithValue("@d", DISTRICTNAMEtextBox2.Text.Trim());
            cmd.ExecuteNonQuery();
            MessageBox.Show("Record Successfully Update", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Information);
            dataGridView1.DataSource = Getdata();
            conn.Close();
        }
        private bool isEmpty()
        {
            if (CITYNAMEtextBox1.Text.Trim() == string.Empty)
            {
               
                    MessageBox.Show("CITY NAME is Required", "ERROR!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                     CITYNAMEtextBox1.Focus();
                    return false;
                
            }
            if (DISTRICTNAMEtextBox2.Text.Trim() == string.Empty)
            {
                MessageBox.Show("DISTRICT NAME is Required", "ERROR!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                DISTRICTNAMEtextBox2.Focus();
                return false;
            }
            return true;
        }

        private void CityandDistrictForm_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = Getdata();
        }

        private DataTable Getdata()
        {
            DataTable dt = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter("select * from CityAndDistric", conn);
            adapter.Fill(dt);
            return dt;
        }
    }
}
