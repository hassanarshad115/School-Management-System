﻿using SchoolManagementSystem.Screens.Templates;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SchoolManagementSystem.Screens.NewStudents
{
    public partial class ManageStudentsForm : TemplateForm
    {
        public ManageStudentsForm()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(ConfigurationClass.ConfigurationClassBnadiH());

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void addNewStudentsRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showById(0, false);
        }

        private void showById(int idV, bool IsupdateV)
        {
            addstudentForm1 obj = new addstudentForm1();
            obj.stdIdP = idV;
            obj.stdisUpdateP = IsupdateV;
            obj.ShowDialog();
        }

        private void ManageStudentsForm_Load(object sender, EventArgs e)
        {
            UpdateDataGridView();
            dataGridView1.Columns[0].Visible = false;
        }

        private void UpdateDataGridView()
        {
            dataGridView1.DataSource = GetData("StdInfoSaw");
        }

        private DataTable GetData(string sp)
        {
            DataTable dt = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(sp, conn);
            adapter.Fill(dt);
            return dt;
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            int index = dataGridView1.Rows.GetFirstRow(DataGridViewElementStates.Selected);
            int row =(int) dataGridView1.Rows[index].Cells[0].Value;

            showById(row, true);

            UpdateDataGridView();
        }
    }
}
