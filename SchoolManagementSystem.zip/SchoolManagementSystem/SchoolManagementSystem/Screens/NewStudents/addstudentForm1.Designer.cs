﻿namespace SchoolManagementSystem.Screens.NewStudents
{
    partial class addstudentForm1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.erollmentnotextBox1 = new System.Windows.Forms.TextBox();
            this.gendercomboBox1 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.admitionnotextBox2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.nametextBox3 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.fathernametextBox4 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dateofadmitiondateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.dateofbirthdateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.citycomboBox2 = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.districtcomboBox3 = new System.Windows.Forms.ComboBox();
            this.addresstextBox5 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.religioncomboBox4 = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRecordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.toplabel13 = new System.Windows.Forms.Label();
            this.branchnamecomboBox1 = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.savebutton1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(12, 100);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "&Enrollment No";
            // 
            // erollmentnotextBox1
            // 
            this.erollmentnotextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.erollmentnotextBox1.Location = new System.Drawing.Point(130, 97);
            this.erollmentnotextBox1.Name = "erollmentnotextBox1";
            this.erollmentnotextBox1.Size = new System.Drawing.Size(183, 23);
            this.erollmentnotextBox1.TabIndex = 0;
            this.erollmentnotextBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // gendercomboBox1
            // 
            this.gendercomboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.gendercomboBox1.FormattingEnabled = true;
            this.gendercomboBox1.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.gendercomboBox1.Location = new System.Drawing.Point(376, 128);
            this.gendercomboBox1.Name = "gendercomboBox1";
            this.gendercomboBox1.Size = new System.Drawing.Size(121, 21);
            this.gendercomboBox1.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(12, 131);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 17);
            this.label2.TabIndex = 0;
            this.label2.Text = "&Admission No";
            // 
            // admitionnotextBox2
            // 
            this.admitionnotextBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.admitionnotextBox2.Location = new System.Drawing.Point(130, 128);
            this.admitionnotextBox2.Name = "admitionnotextBox2";
            this.admitionnotextBox2.Size = new System.Drawing.Size(183, 23);
            this.admitionnotextBox2.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(12, 132);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 17);
            this.label3.TabIndex = 0;
            this.label3.Text = "&Name";
            // 
            // nametextBox3
            // 
            this.nametextBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nametextBox3.Location = new System.Drawing.Point(130, 183);
            this.nametextBox3.Name = "nametextBox3";
            this.nametextBox3.Size = new System.Drawing.Size(183, 23);
            this.nametextBox3.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(12, 215);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 17);
            this.label4.TabIndex = 0;
            this.label4.Text = "&Father Name";
            // 
            // fathernametextBox4
            // 
            this.fathernametextBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fathernametextBox4.Location = new System.Drawing.Point(130, 212);
            this.fathernametextBox4.Name = "fathernametextBox4";
            this.fathernametextBox4.Size = new System.Drawing.Size(183, 23);
            this.fathernametextBox4.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(12, 157);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(122, 17);
            this.label5.TabIndex = 0;
            this.label5.Text = "&Date of Admission";
            // 
            // dateofadmitiondateTimePicker1
            // 
            this.dateofadmitiondateTimePicker1.Location = new System.Drawing.Point(130, 157);
            this.dateofadmitiondateTimePicker1.Name = "dateofadmitiondateTimePicker1";
            this.dateofadmitiondateTimePicker1.Size = new System.Drawing.Size(183, 20);
            this.dateofadmitiondateTimePicker1.TabIndex = 2;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Location = new System.Drawing.Point(12, 241);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(87, 17);
            this.label6.TabIndex = 0;
            this.label6.Text = "&Date of Birth";
            // 
            // dateofbirthdateTimePicker2
            // 
            this.dateofbirthdateTimePicker2.Location = new System.Drawing.Point(130, 241);
            this.dateofbirthdateTimePicker2.Name = "dateofbirthdateTimePicker2";
            this.dateofbirthdateTimePicker2.Size = new System.Drawing.Size(183, 20);
            this.dateofbirthdateTimePicker2.TabIndex = 5;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label7.Location = new System.Drawing.Point(314, 132);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(56, 17);
            this.label7.TabIndex = 0;
            this.label7.Text = "&Gender";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label8.Location = new System.Drawing.Point(314, 160);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(31, 17);
            this.label8.TabIndex = 0;
            this.label8.Text = "&City";
            // 
            // citycomboBox2
            // 
            this.citycomboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.citycomboBox2.FormattingEnabled = true;
            this.citycomboBox2.Location = new System.Drawing.Point(376, 157);
            this.citycomboBox2.Name = "citycomboBox2";
            this.citycomboBox2.Size = new System.Drawing.Size(121, 21);
            this.citycomboBox2.TabIndex = 9;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label9.Location = new System.Drawing.Point(314, 186);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(51, 17);
            this.label9.TabIndex = 0;
            this.label9.Text = "&District";
            // 
            // districtcomboBox3
            // 
            this.districtcomboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.districtcomboBox3.FormattingEnabled = true;
            this.districtcomboBox3.Location = new System.Drawing.Point(376, 185);
            this.districtcomboBox3.Name = "districtcomboBox3";
            this.districtcomboBox3.Size = new System.Drawing.Size(121, 21);
            this.districtcomboBox3.TabIndex = 10;
            // 
            // addresstextBox5
            // 
            this.addresstextBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addresstextBox5.Location = new System.Drawing.Point(130, 267);
            this.addresstextBox5.Multiline = true;
            this.addresstextBox5.Name = "addresstextBox5";
            this.addresstextBox5.Size = new System.Drawing.Size(183, 73);
            this.addresstextBox5.TabIndex = 6;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label10.Location = new System.Drawing.Point(12, 267);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(60, 17);
            this.label10.TabIndex = 0;
            this.label10.Text = "&Address";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label11.Location = new System.Drawing.Point(314, 215);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(59, 17);
            this.label11.TabIndex = 0;
            this.label11.Text = "&Religion";
            // 
            // religioncomboBox4
            // 
            this.religioncomboBox4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.religioncomboBox4.FormattingEnabled = true;
            this.religioncomboBox4.Items.AddRange(new object[] {
            "Islam",
            "Cheristin",
            "Hindu",
            "Sikh"});
            this.religioncomboBox4.Location = new System.Drawing.Point(376, 212);
            this.religioncomboBox4.Name = "religioncomboBox4";
            this.religioncomboBox4.Size = new System.Drawing.Size(121, 21);
            this.religioncomboBox4.TabIndex = 11;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label12.Location = new System.Drawing.Point(12, 186);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(45, 17);
            this.label12.TabIndex = 0;
            this.label12.Text = "&Name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SchoolManagementSystem.Properties.Resources.no_image_available;
            this.pictureBox1.Location = new System.Drawing.Point(317, 241);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(180, 133);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.closeToolStripMenuItem,
            this.toolStripMenuItem1,
            this.saveRecordToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(514, 24);
            this.menuStrip1.TabIndex = 5;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.closeToolStripMenuItem.Text = "&Close";
            this.closeToolStripMenuItem.Click += new System.EventHandler(this.closeToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(22, 20);
            this.toolStripMenuItem1.Text = "|";
            // 
            // saveRecordToolStripMenuItem
            // 
            this.saveRecordToolStripMenuItem.Name = "saveRecordToolStripMenuItem";
            this.saveRecordToolStripMenuItem.Size = new System.Drawing.Size(22, 20);
            this.saveRecordToolStripMenuItem.Text = " ";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.toplabel13);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 24);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(514, 67);
            this.panel1.TabIndex = 6;
            // 
            // toplabel13
            // 
            this.toplabel13.Font = new System.Drawing.Font("Elephant", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toplabel13.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.toplabel13.Location = new System.Drawing.Point(97, 12);
            this.toplabel13.Name = "toplabel13";
            this.toplabel13.Size = new System.Drawing.Size(308, 45);
            this.toplabel13.TabIndex = 0;
            this.toplabel13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // branchnamecomboBox1
            // 
            this.branchnamecomboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.branchnamecomboBox1.FormattingEnabled = true;
            this.branchnamecomboBox1.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.branchnamecomboBox1.Location = new System.Drawing.Point(376, 101);
            this.branchnamecomboBox1.Name = "branchnamecomboBox1";
            this.branchnamecomboBox1.Size = new System.Drawing.Size(121, 21);
            this.branchnamecomboBox1.TabIndex = 7;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label13.Location = new System.Drawing.Point(314, 103);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(53, 17);
            this.label13.TabIndex = 0;
            this.label13.Text = "&Branch";
            // 
            // savebutton1
            // 
            this.savebutton1.Location = new System.Drawing.Point(130, 346);
            this.savebutton1.Name = "savebutton1";
            this.savebutton1.Size = new System.Drawing.Size(183, 26);
            this.savebutton1.TabIndex = 12;
            this.savebutton1.Text = "Save Record";
            this.savebutton1.UseVisualStyleBackColor = true;
            this.savebutton1.Click += new System.EventHandler(this.savebutton1_Click);
            // 
            // addstudentForm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(514, 384);
            this.Controls.Add(this.savebutton1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.dateofbirthdateTimePicker2);
            this.Controls.Add(this.dateofadmitiondateTimePicker1);
            this.Controls.Add(this.religioncomboBox4);
            this.Controls.Add(this.districtcomboBox3);
            this.Controls.Add(this.citycomboBox2);
            this.Controls.Add(this.branchnamecomboBox1);
            this.Controls.Add(this.gendercomboBox1);
            this.Controls.Add(this.addresstextBox5);
            this.Controls.Add(this.fathernametextBox4);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.admitionnotextBox2);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.nametextBox3);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.erollmentnotextBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "addstudentForm1";
            this.ShowInTaskbar = true;
            this.Text = "addstudentForm1";
            this.Load += new System.EventHandler(this.addstudentForm1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox erollmentnotextBox1;
        private System.Windows.Forms.ComboBox gendercomboBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox admitionnotextBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox nametextBox3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox fathernametextBox4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dateofadmitiondateTimePicker1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker dateofbirthdateTimePicker2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox citycomboBox2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox districtcomboBox3;
        private System.Windows.Forms.TextBox addresstextBox5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox religioncomboBox4;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem saveRecordToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label toplabel13;
        private System.Windows.Forms.ComboBox branchnamecomboBox1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button savebutton1;
    }
}