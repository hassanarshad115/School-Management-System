﻿using SchoolManagementSystem.Screens.Templates;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SchoolManagementSystem.Screens.NewStudents
{
    public partial class addstudentForm1 : TemplateForm
    {
        public addstudentForm1()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(ConfigurationClass.ConfigurationClassBnadiH());
        public int stdIdP { get; set; }
        public bool stdisUpdateP { get; set; }
        private void addstudentForm1_Load(object sender, EventArgs e)
        {
            branchnamecomboBox1.DataSource = GetData("select BranchName from Branches");
            branchnamecomboBox1.DisplayMember = "BranchName";
            branchnamecomboBox1.SelectedIndex = -1;
            citycomboBox2.DataSource = GetData("select City from Branches");
            citycomboBox2.DisplayMember = "City";
            citycomboBox2.SelectedIndex = -1;
            districtcomboBox3.DataSource = GetData("select District from Branches");
            districtcomboBox3.DisplayMember = "District";
            districtcomboBox3.SelectedIndex = -1;


            if (stdisUpdateP)//ye lazmi yad rkhna k updatep ko likhna ha if ma r kch ni
            {
                DataTable dt = GetDataGyId(stdIdP);
                DataRow row = dt.Rows[0];
                erollmentnotextBox1.Text = row["EnrollmentNo"].ToString();
                admitionnotextBox2.Text = row["AdmissionNo"].ToString();
                dateofadmitiondateTimePicker1.Text = row["dateOfAdmission"].ToString();
                nametextBox3.Text = row["Name"].ToString();
                fathernametextBox4.Text = row["FatherName"].ToString();
                dateofbirthdateTimePicker2.Text = row["DateOfBirth"].ToString();
                addresstextBox5.Text = row["Address"].ToString();
                gendercomboBox1.Text = row["Gender"].ToString();
                citycomboBox2.Text = row["City"].ToString();
                districtcomboBox3.Text = row["District"].ToString();
                religioncomboBox4.Text = row["Religion"].ToString();
                branchnamecomboBox1.Text = row["BranchName"].ToString();

                pictureBox1.Image = getImageFromDataBase((byte[])row["Image"]);


            }

        }
        //database sy image ko access krny k lye
        private Image getImageFromDataBase(byte[] veriable)
        {
            System.IO.MemoryStream ms = new System.IO.MemoryStream(veriable);
            return Image.FromStream(ms);
        }

        //sqlcommand ko datatable k sath kia ha attach
        private DataTable GetDataGyId(int stdIdP)
        {
            DataTable dt = new DataTable();
            SqlCommand cmd = new SqlCommand("stdSelectById", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            conn.Open();
            cmd.Parameters.AddWithValue("@id", stdIdP);
            SqlDataReader r = cmd.ExecuteReader();
            dt.Load(r);

            return dt;
        }

        //ye district r city ko ly kr ayga Branches table sy
        private DataTable GetData(string sp)
        {
            DataTable dt = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(sp, conn);
            adapter.Fill(dt);
            return dt;
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            toplabel13.Text = erollmentnotextBox1.Text;
        }
        //first choose image then it fill into imagebox 
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "Select Student Picture";
            ofd.Filter = "Select Picture(*.JPG;*.PNG;*|*.jpg;*.png)";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image = new Bitmap(ofd.FileName);
            }
        }

     //save buutton ma isupdate k sath 2 method bnay hain save r update k lye
        private void savebutton1_Click(object sender, EventArgs e)
        {
            if (isEmpty()) //if any textbox is empyt then error is occur
            {
                if (stdisUpdateP) //update property k sath isko kia ha
                {
                    UpdateKLye(); // phly update ka kam hoga
                }
                else //wrna
                {
                    SaveKlye(); // save hojayga data database ma
                }
            }
        }

        //its code for update data
        private void UpdateKLye()
        {
            SqlCommand cmd = new SqlCommand("sp_stdUpdate", conn);//idher sy strt krna ha
            cmd.CommandType = CommandType.StoredProcedure;
            try
            {
                //conn.Open();
                cmd.Parameters.AddWithValue("@enrollmentNo", erollmentnotextBox1.Text.Trim());
                cmd.Parameters.AddWithValue("@admissionNo", admitionnotextBox2.Text.Trim());
                cmd.Parameters.AddWithValue("@dataofAdmission", dateofadmitiondateTimePicker1.Value.Date);
                cmd.Parameters.AddWithValue("@name", nametextBox3.Text.Trim());
                cmd.Parameters.AddWithValue("@fatherName", fathernametextBox4.Text.Trim());
                cmd.Parameters.AddWithValue("@dateofBirth", dateofbirthdateTimePicker2.Value.Date);
                cmd.Parameters.AddWithValue("@address", addresstextBox5.Text.Trim());
                cmd.Parameters.AddWithValue("@gender", gendercomboBox1.Text);
                cmd.Parameters.AddWithValue("@city", citycomboBox2.Text);
                cmd.Parameters.AddWithValue("@district", districtcomboBox3.Text);
                cmd.Parameters.AddWithValue("@religion", religioncomboBox4.Text);
                cmd.Parameters.AddWithValue("@image", GetPhotoFirst());

                cmd.Parameters.AddWithValue("@branchName", branchnamecomboBox1.Text);
                cmd.ExecuteNonQuery();
                conn.Close();
                MessageBox.Show("Successfully Update Data", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.Close();
                ManageStudentsForm obj = new ManageStudentsForm();
                obj.Show();
            }
            catch (ApplicationException ex)
            {
                MessageBox.Show("ERROR IN UPDATE CODING", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }


        DataSet ds = new DataSet();
        SqlCommand cmd1;
        private void SaveKlye()
        {
            //agr enrollement number phly he ho to ye error dy k phly he database ma ye error mojod ha
            cmd1 = new SqlCommand("select * from [dbo].[StdInfoTbl] where [EnrollmentNo]='" + erollmentnotextBox1.Text.Trim() + "'", conn);
            SqlDataAdapter adapter = new SqlDataAdapter(cmd1);
            adapter.Fill(ds);
            int i = ds.Tables[0].Rows.Count;
            if (i > 0)
            {
                MessageBox.Show("Branche Name " + erollmentnotextBox1.Text + " is Already Exist", "ERROR!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
            }
            else
            {
                //its for save different textbox data into database
                SqlCommand cmd = new SqlCommand("sp_stdInsert", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                conn.Open();
                cmd.Parameters.AddWithValue("@enrollmentNo", erollmentnotextBox1.Text.Trim());
                cmd.Parameters.AddWithValue("@admissionNo", admitionnotextBox2.Text.Trim());
                cmd.Parameters.AddWithValue("@dataofAdmission", dateofadmitiondateTimePicker1.Value.Date);
                cmd.Parameters.AddWithValue("@name", nametextBox3.Text.Trim());
                cmd.Parameters.AddWithValue("@fatherName", fathernametextBox4.Text.Trim());
                cmd.Parameters.AddWithValue("@dateofBirth", dateofbirthdateTimePicker2.Value.Date);
                cmd.Parameters.AddWithValue("@address", addresstextBox5.Text.Trim());
                cmd.Parameters.AddWithValue("@gender", gendercomboBox1.Text);
                cmd.Parameters.AddWithValue("@city", citycomboBox2.Text);
                cmd.Parameters.AddWithValue("@district", districtcomboBox3.Text);
                cmd.Parameters.AddWithValue("@religion", religioncomboBox4.Text);
                cmd.Parameters.AddWithValue("@image", GetPhotoFirst());

                cmd.Parameters.AddWithValue("@branchName", branchnamecomboBox1.Text);
                cmd.ExecuteNonQuery();
                conn.Close();
                MessageBox.Show("Successfully Saved Data", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.Close();
                ManageStudentsForm obj = new ManageStudentsForm();
                obj.Show();
            }
        }
        //its for save image into database
        private byte[] GetPhotoFirst()
        {
            System.IO.MemoryStream ms = new System.IO.MemoryStream();
            pictureBox1.Image.Save(ms, pictureBox1.Image.RawFormat);
            return ms.GetBuffer();
        }

        //agr any textbox empty hoto error occur hojay
        private bool isEmpty()
        {
            if (erollmentnotextBox1.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Enrollment No is Required", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                erollmentnotextBox1.Focus();
                return false;
            }
            if (admitionnotextBox2.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Admission No is Required", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                admitionnotextBox2.Focus();
                return false;
            }
            if (nametextBox3.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Name is Required", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                nametextBox3.Focus();
                return false;
            }
            if (fathernametextBox4.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Father Name is Required", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                fathernametextBox4.Focus();
                return false;
            }
            if (addresstextBox5.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Address is Required", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                addresstextBox5.Focus();
                return false;
            }
            if (branchnamecomboBox1.Text == string.Empty)
            {
                MessageBox.Show("Branch Name is Required", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            if (citycomboBox2.Text == string.Empty)
            {
                MessageBox.Show("City Name is Required", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            if (districtcomboBox3.Text == string.Empty)
            {
                MessageBox.Show("District Name is Required", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            if (religioncomboBox4.Text == string.Empty)
            {
                MessageBox.Show("Religion Name is Required", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true; // return error hojay
        }

      
    }
}
