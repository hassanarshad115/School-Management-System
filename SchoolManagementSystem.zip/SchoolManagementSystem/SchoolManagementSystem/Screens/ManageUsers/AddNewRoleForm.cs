﻿using SchoolManagementSystem.Screens.Templates;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SchoolManagementSystem.Screens.ManageUsers
{
    public partial class AddNewRoleForm : TemplateForm
    {
        public AddNewRoleForm()
        {
            InitializeComponent();
        }
        public string rolep { get; set; }
        public string createdbyinrolep { get; set; }
        public bool delbuttoninroleP { get; set; }
        SqlConnection conn = new SqlConnection(ConfigurationClass.ConfigurationClassBnadiH());
        DataSet ds = new DataSet();
        SqlCommand cm;
        private void savebutton3_Click(object sender, EventArgs e)
        {
            if (isEmpty())
            {
                cm = new SqlCommand(" select * from Role where Descriptioin= '" + roletextBox1.Text.Trim() + "'", conn);
                SqlDataAdapter adapter = new SqlDataAdapter(cm);
                adapter.Fill(ds);
                int i = ds.Tables[0].Rows.Count;
                if (i > 0)
                {
                    MessageBox.Show("Role "+roletextBox1.Text+" is already exists", "Error!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.Close();
                }
                else { 
                    SqlCommand cmd = new SqlCommand("insert into Role(Descriptioin,CreatedBy) values(@d,@c)", conn);
                    cmd.Parameters.AddWithValue("@d", roletextBox1.Text.Trim());
                    cmd.Parameters.AddWithValue("@c", createdbytextBox2.Text.Trim());
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    MessageBox.Show("Save Data Successfully", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Information);
                 
                    ManageUsersForm obj = new ManageUsersForm();
                    obj.Show();
                    this.Hide();
                }
            }
        }

        private bool isEmpty()
        {
            if (roletextBox1.Text == string.Empty)
            {
                MessageBox.Show("Role is Required", "Error!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                roletextBox1.Focus();
                return false;
            }
            if (createdbytextBox2.Text == string.Empty)
            {
                MessageBox.Show("CreatedBy is Required", "Error!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                createdbytextBox2.Focus();
                return false;
            }
            return true;
        }

       
        private void deletebutton2_Click(object sender, EventArgs e)
        {
            if (isEmpty())
            {
                DialogResult result = MessageBox.Show("Do you want to delete Record ??", "WARNING", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                if (result == DialogResult.OK)
                {
                    SqlCommand cmd = new SqlCommand("delete from Role where Descriptioin=@d and CreatedBy=@c ", conn);
                    cmd.Parameters.AddWithValue("@d", roletextBox1.Text.Trim());
                    cmd.Parameters.AddWithValue("@c", createdbytextBox2.Text.Trim());
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    MessageBox.Show("Delete Data Successfully", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Information);
                   
                    ManageUsersForm obj = new ManageUsersForm();
                    obj.Show();
                    this.Hide();
                }
            }
        }

        private void AddNewRoleForm_Load(object sender, EventArgs e)
        {
            roletextBox1.Text = rolep;
            createdbytextBox2.Text = createdbyinrolep;
            deletebutton2.Enabled = delbuttoninroleP;
        }
    }
}
