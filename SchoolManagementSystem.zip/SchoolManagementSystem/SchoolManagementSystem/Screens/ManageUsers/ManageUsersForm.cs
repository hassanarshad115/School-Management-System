﻿using SchoolManagementSystem.Screens.Templates;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SchoolManagementSystem.Screens.ManageUsers
{
    public partial class ManageUsersForm : TemplateForm
    {
        public ManageUsersForm()
        {
            InitializeComponent();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        SqlConnection conn = new SqlConnection(ConfigurationClass.ConfigurationClassBnadiH());
        private void ManageUsersForm_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = GetData("select Descriptioin as Role,CreatedBy  from Role");
        }
        private DataTable GetData(string sp)
        {
            DataTable dt = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(sp, conn);
            adapter.Fill(dt);
            return dt;
        }

        private void addNewRoleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            AddNewRoleForm anr = new AddNewRoleForm();
            anr.ShowDialog();
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            AddNewRoleForm adnform = new AddNewRoleForm();
            int index = dataGridView1.Rows.GetFirstRow(DataGridViewElementStates.Selected);
            string obj =Convert.ToString( dataGridView1.Rows[index].Cells[0].Value);
            string obj1 = Convert.ToString(dataGridView1.Rows[index].Cells[1].Value);


            adnform.rolep = obj.ToString();
            adnform.createdbyinrolep = obj1.ToString();
            adnform.delbuttoninroleP = true;
            adnform.Show();
           
        }
    }
}
