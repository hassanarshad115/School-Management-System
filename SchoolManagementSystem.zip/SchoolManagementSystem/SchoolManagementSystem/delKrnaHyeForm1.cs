﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;
using Excel;
using System.IO;
using System.Configuration;


namespace SchoolManagementSystem
{
    public partial class delKrnaHyeForm1 : Form
    {
        public delKrnaHyeForm1()
        {
            InitializeComponent();
        }

        private void textBox1_Validating(object sender, CancelEventArgs e)
        {
            //if (string.IsNullOrEmpty(textBox1.Text)) { }
        }
        //public bool IsFirstRowAsColumnNames { get; set; }
        DataSet res;
        private void button1_Click(object sender, EventArgs e)
        {
            //Subject 1
            using (OpenFileDialog ofd = new OpenFileDialog() { Filter = "Excel Workbook |*.xls", ValidateNames = true })
            {
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    FileStream fs = File.Open(ofd.FileName, FileMode.Open, FileAccess.Read);
                    IExcelDataReader reader = ExcelReaderFactory.CreateBinaryReader(fs);
                    reader.IsFirstRowAsColumnNames = true;
                    res = reader.AsDataSet();
                    comboBox1.Items.Clear();
                    foreach (DataTable dt in res.Tables)
                    {
                        comboBox1.Items.Add(dt.TableName);
                        reader.Close();
                    }
                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            dataGridView1.DataSource = res.Tables[comboBox1.SelectedIndex];

            dataGridView1.Columns.Add("newColumnName", "CGPA");

            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                marks = Convert.ToInt16(dataGridView1.Rows[i].Cells[2].Value);
                //GPACall();
                dataGridView1.Rows[i].Cells[3].Value = a;
            }
            //dataGridView1.Refresh();

        }
        int marks;
        string a;
    }
}
